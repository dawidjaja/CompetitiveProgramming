<?php 
$the_array = Array();
$me = $_SERVER['PHP_SELF'];

if ($handle = opendir('.')) {
   while (false !== ($file = readdir($handle))) { 
       if ($file != "." && $file != ".." && $file != "index.php") { 
           $the_array[] = $file;
       } 
   }
   closedir($handle); 
   sort ($the_array);
   reset ($the_array);
   echo "<strong><u>Directory Listing for http://www.cs.sunyb.edu$me</u></strong>";
   echo "<BR><BR>"; 
   while (list ($key, $val) = each ($the_array)) {
       echo "<a href=\"$val\">$val</a><BR>\n"; 
   }
}
?> 

