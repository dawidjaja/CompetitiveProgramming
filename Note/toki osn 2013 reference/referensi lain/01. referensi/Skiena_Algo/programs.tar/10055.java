
/*   @JUDGE_ID:   15451CF   10055   Java   "Esse e ridicul  
 Permission is granted for use in non-commerical applications  
 provided this copyright notice remains intact and unchanged.*/ 

 
#include<stdio.h>

int main() {
      long p,q,r;

      while (scanf("%ld %ld",&p,&q)
		!=EOF) {
 	if (q>p) r=q-p;
        else r=p-q;

        printf("%ld\n",r);
      }
}

